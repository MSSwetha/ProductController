package com.example.demo;

import org.springframework.context.annotation.Bean;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class SortProduct {

    List<Product> list=new ArrayList<Product>();
    Product s1=new Product("Prod1","Shirt","EACH");
    Product s2=new Product("Prod2","Trousers","EACH");
    Product s3=new Product("Prod3","Tie","EACH");

    @Override
    public List<Product> getProduct()
    {
        return null;
    }


}
