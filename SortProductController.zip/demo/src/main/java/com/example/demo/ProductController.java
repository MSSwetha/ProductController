package com.example.demo;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class ProductController {

    private static final String template1 ="%a";
    private static final String template2="%b";
    private static final String template3="%c";
    private static final String template4="%d";
    private final AtomicLong counter = new AtomicLong();

    @GetMapping("/createProduct")
    public Product createProduct(@RequestParam(value = "prodId", defaultValue = 1) long prodId) {
        return new Product(counter.incrementAndGet(), String.format(template1, prodId));
    }
    public Product createProduct(@RequestParam(value = "prodName", defaultValue = "Shirt") String prodName) {
        return new Product(counter.incrementAndGet(), String.format(template2, prodName));
    }
    public Product createProduct(@RequestParam(value = "measure", defaultValue = "EACH") String measure) {
        return new Product(counter.incrementAndGet(), String.format(template2, measure));
    }
    public Product createProduct(@RequestParam(value = "status", defaultValue = "Exists") String status) {
        return new Product(counter.incrementAndGet(), String.format(template2, status));
    }
}
