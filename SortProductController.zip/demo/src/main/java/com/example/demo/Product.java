package com.example.demo;

public class Product {
    private String prodId;
    private String prodName;
    private String measure;
    private String status;

    public Product(String prodId,String prodName,String measure,String status)
    {
        this.prodId=prodId;
        this.prodName=prodName;
        this.measure=measure;
        this.status=status;
    }

    public String getProdId() {
        return prodId;
    }

    public String getProdName() {
        return prodName;
    }

    public String getMeasure() {
        return measure;
    }

    public String getStatus() {
        return status;
    }

    public void setProdName(String prodName) {
        this.prodName = prodName;
    }

    public void setProdId(String prodId) {
        this.prodId = prodId;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public void setMeasure(String measure) {
        this.measure = measure;
    }
}
