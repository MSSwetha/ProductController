package com.example.demo;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class SortProductController {
    private SortProduct sp;

    @PutMapping("/createProduct")
    public list<Product> getProduct() {
        return this.SortProduct.getProduct();
    }
}

